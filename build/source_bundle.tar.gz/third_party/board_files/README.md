# Official AMD KV260 board files

Source: https://github.com/Xilinx/XilinxBoardStore

Branch: `2025.2`; commit: `8770a18adc2c6bb0df0b1ef60fcbbd833e6134c3`.
Vendored unchanged: `boards/Xilinx/kv260_som/1.4` and `boards/Xilinx/kv260_carrier/1.3`.
Each directory retains the upstream Apache-2.0 license. File hashes are in `manifest.json`.
All XML files parsed successfully with Python ElementTree. Vivado schema/catalog loading is pending installation.
Build scripts use this repository locally via `board.repoPaths`; no global Vivado settings are changed.
