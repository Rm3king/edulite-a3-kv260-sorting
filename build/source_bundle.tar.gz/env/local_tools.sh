#!/usr/bin/env bash
# Use tools already installed by the user; never alter shell startup files.
command -v dtc >/dev/null || { echo 'Install device-tree-compiler (dtc) before packaging.' >&2; return 2; }
