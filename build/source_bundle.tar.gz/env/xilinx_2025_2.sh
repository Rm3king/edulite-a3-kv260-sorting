#!/usr/bin/env bash
# Source a caller-selected toolchain; no reference to the development machine.
if [[ -n "${XILINX_SETTINGS64:-}" ]]; then
    [[ -f "$XILINX_SETTINGS64" ]] || { echo "Settings file not found: $XILINX_SETTINGS64" >&2; return 2; }
    kv260_nounset=0
    [[ $- != *u* ]] || kv260_nounset=1
    set +u
    source "$XILINX_SETTINGS64"
    kv260_settings_rc=$?
    [[ "$kv260_nounset" == 0 ]] || set -u
    [[ "$kv260_settings_rc" == 0 ]] || return "$kv260_settings_rc"
    unset kv260_nounset kv260_settings_rc
fi
command -v vivado >/dev/null || { echo 'Source Vivado 2025.2 settings64.sh, or set XILINX_SETTINGS64 to that file.' >&2; return 2; }
export FPGA_BUILD_JOBS="${FPGA_BUILD_JOBS:-2}"
export FPGA_BUILD_THREADS="${FPGA_BUILD_THREADS:-4}"
