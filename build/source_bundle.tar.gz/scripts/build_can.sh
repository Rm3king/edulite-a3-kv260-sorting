#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
root="$PWD"
stage="${1:-create}"
case "$stage" in create|ooc|synth|impl|bitstream) ;; *) exit 2;; esac
mkdir -p contest/kv260_can/build contest/kv260_can/result
if [[ "$stage" != ooc ]]; then
 /usr/bin/python3 scripts/validate_fk_batch_ip.py
 /usr/bin/python3 scripts/validate_vision_pre_ip.py
fi
sha256sum contest/kv260_can/rtl/* contest/kv260_can/tcl/* contest/kv260_can/constraints/* third_party/opencores_can/*.v contest/fk_batch/source/* contest/vision_pre/source/* > contest/kv260_can/result/build_sources.sha256
log="$root/contest/kv260_can/result/${stage}_$(date +%Y%m%d_%H%M%S).log"
(
 source "$root/env/xilinx_2025_2.sh"
 cd "$root/contest/kv260_can/build"
 vivado -mode batch -notrace -source "$root/contest/kv260_can/tcl/build.tcl" -tclargs "$stage"
) > "$log" 2>&1 || { tail -n 45 "$log"; exit 1; }
sha256sum --check contest/kv260_can/result/build_sources.sha256 > contest/kv260_can/result/build_sources_check.log
if [[ "$stage" != ooc ]]; then
 /usr/bin/python3 scripts/validate_fk_batch_ip.py
 /usr/bin/python3 scripts/validate_vision_pre_ip.py
fi
tail -n 12 "$log"
