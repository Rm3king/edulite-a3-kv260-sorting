#!/usr/bin/python3
"""Create a Linux FPGA-manager bundle only from matching tested/built sources."""
from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parents[1];exp=r/'contest/kv260_can'
assert (exp/'result/build_validation.txt').read_text().startswith('PASS:')
tests=json.loads((exp/'result/latest_validation.json').read_text())
assert tests['status']=='PASS'
for name,wanted in tests['sources'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==wanted,name
subprocess.run(['sha256sum','--check',str(exp/'result/build_sources.sha256')],cwd=r,check=True)
subprocess.run(['/usr/bin/python3',str(r/'scripts/validate_fk_batch_ip.py')],cwd=r,check=True)
subprocess.run(['/usr/bin/python3',str(r/'scripts/validate_vision_pre_ip.py')],cwd=r,check=True)
subprocess.run(['/usr/bin/python3',str(r/'scripts/collect_kv260_metrics.py'),'--experiment','contest/kv260_can','--basename','kv260_can','--scope','final merged design: PS/AXI/HLS trajectory evaluation/CSP CAN/deadline queues/feedback guard/7-axis tracking watchdog (monitor only)/HLS image pre-processing kernel with DMA; no ILA, no FK batch core'],check=True,cwd=r)
out=r/'.cache/kv260_can_deploy';out.mkdir(exist_ok=True)
# AMD bootgen performs the required bitstream byte ordering for FPGA manager.
bif=exp/'build/bitstream.bif';bif.write_text('all:\n{\n  '+str(exp/'build/kv260_can.bit')+'\n}\n')
subprocess.run(['bash','-c','source env/xilinx_2025_2.sh\nbootgen -image contest/kv260_can/build/bitstream.bif -arch zynqmp -process_bitstream bin -w on'],cwd=r,check=True)
shutil.copy2(exp/'build/kv260_can.bit.bin',out/'kv260-can.bit.bin')
subprocess.run(['bash','-c','source env/local_tools.sh\ndtc -@ -I dts -O dtb -o .cache/kv260_can_deploy/kv260-can.dtbo contest/kv260_can/constraints/kv260-can.dts'],cwd=r,check=True)
software=['canctl.py','install_board.sh','a3_protocol.py','mmio.c','board_validate.py','tracking_monitor.py','read_arm.py',
          'joint_safety.py','board_guard_validate.py','gripper_commission.py','probe_arm_parameters.py','arm_commission.py','board_pp_validate.py','board_rx_buffer_validate.py']
for name in software:shutil.copy2(exp/'software'/name,out/name)
runtime=['joint_trajectory.py','motion_profile.json','pl_transport.py','csp_commission.py','board_correction_validate.py','control_continuity.py']
for name in runtime:shutil.copy2(r/'contest/arm_runtime'/name,out/name)
shutil.copy2(exp/'config/a3_commissioning.json',out/'a3_commissioning.json')
# Board side of the PL wrist-camera kernel: driver, ARM baseline/fallback, components, screw observation, allocator source.
vision=['vision_pre.py','vision_ref.c','vision_cache.c','vision_blobs.c','wrist_locator.py','vision_alloc.c','replay.py','wrist_vision_loop.py',
        # the AI PC servo's own locators, run unchanged by wrist_vision_loop (OpenCV on the board); copies of aipc_app/integration/workcell
        'wrist_nut_localization.py','wrist_m6_localization.py','HOST_LOCATORS.sha256']
for name in vision:shutil.copy2(r/'contest/vision_pre/board'/name,out/name)
(out/'shell.json').write_text('{"shell_type":"XRT_FLAT","num_slots":"1"}\n')
files=['kv260-can.bit.bin','kv260-can.dtbo','shell.json','a3_commissioning.json']+software+runtime+vision
# The online correction channel exists only in bitstreams built from a trajectory_stream with it; the marker binds
# that fact to this bundle's bitstream hash (canctl.correction_channel_present). Older bundles carry no marker.
(out/'correction_channel.json').unlink(missing_ok=True)
if 'corr_target' in (exp/'rtl/trajectory_stream.sv').read_text():
    (out/'correction_channel.json').write_text(json.dumps(dict(bitstream='kv260-can.bit.bin',sha256=hashlib.sha256((out/'kv260-can.bit.bin').read_bytes()).hexdigest(),
        registers='840 ctrl, 848 step, 84c lease_us, 850..864 targets, 870..884 applied, 888 writes, 88c clamps, 890 age, 894 id, 898 rejects, 8a0..8b4 limits'))+'\n')
    files.append('correction_channel.json')
(out/'SHA256SUMS').write_text(''.join(hashlib.sha256((out/f).read_bytes()).hexdigest()+'  '+f+'\n' for f in files))
print('READY',out,'Deploy with bash scripts/deploy_can.sh; uses project passwordless access when installed.')
