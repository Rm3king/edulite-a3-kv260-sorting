#!/usr/bin/env python3
"""Collect implemented system resources/timing and hash actual hardware artifacts."""
import hashlib
import argparse
import json
import re
from datetime import datetime
from pathlib import Path

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--experiment', default='learning/01_kv260_pl_blink')
parser.add_argument('--basename', default='kv260_pl_blink')
parser.add_argument('--scope', default='complete PS/reset/counter/ILA/debug-hub system')
args = parser.parse_args()
exp = (root / args.experiment).resolve()
result = exp / 'result'
validation = result / 'build_validation.txt'
if not validation.exists() or not validation.read_text().startswith('PASS:'):
    raise SystemExit('No completed implementation/bitstream/XSA validation record')
util = (result / 'impl_utilization.rpt').read_text()
resources = {}
for key, label in {'LUT': 'CLB LUTs', 'FF': 'CLB Registers',
                   'BRAM_36K_tiles': 'Block RAM Tile', 'URAM': 'URAM', 'DSP': 'DSPs'}.items():
    m = re.search(r'^\|\s*' + re.escape(label) + r'\s*\|\s*([\d.]+)', util, re.M)
    if not m:
        raise ValueError(f'Missing utilization row {label}')
    resources[key] = float(m[1]) if '.' in m[1] else int(m[1])
summary = (result / 'impl_timing.rpt').read_text().split('WNS(ns)', 1)[1]
values = None
for line in summary.splitlines():
    if re.match(r'^\s*-?\d+\.\d+\s+-?\d+\.\d+\s+\d+\s+\d+', line):
        values = line.split()
        break
if not values:
    raise ValueError('No timing summary numeric row found')
timing = {k: float(values[i]) for k, i in
          {'WNS_ns': 0, 'TNS_ns': 1, 'WHS_ns': 4, 'THS_ns': 5}.items()}
bus_skew = (result / 'bus_skew.rpt').read_text()
slacks = [float(x) for x in re.findall(r'Slack \(MET\)\s*:\s*(-?[\d.]+)ns', bus_skew)]
if 'VIOLATED' in bus_skew or (slacks and min(slacks) < 0):
    raise ValueError('Bus skew constraints violated')
if not slacks:
    # No asynchronous bus crossing exists only when the routed design has a single clock and no CDC/unconstrained paths:
    # accepted on that evidence (clocks.rpt lists one clock, check_timing is clean), never silently.
    clocks = (result / 'clocks.rpt').read_text()
    clock_rows = re.findall(r'^(\S+)\s+[\d.]+\s+\{[^}]*\}\s+\S*\s+\{[^}]*\}\s*$', clocks, re.M)
    check = (result / 'check_timing.rpt').read_text()
    clean = all(re.search(r'checking %s \(0\)' % name, check) for name in
                ('no_clock', 'unconstrained_internal_endpoints', 'multiple_clock', 'generated_clocks', 'loops', 'latch_loops'))
    if 'No bus skew constraints' not in bus_skew or len(clock_rows) != 1 or not clean:
        raise ValueError('Bus skew constraints missing and the single-clock evidence is not met')
    timing['bus_skew_note'] = 'No bus skew constraints: single clock %s, check_timing clean' % clock_rows[0]
    timing['bus_skew_min_slack_ns'] = None
    timing['bus_skew_constraints_checked'] = 0
else:
    timing['bus_skew_min_slack_ns'] = min(slacks)
    timing['bus_skew_constraints_checked'] = len(slacks)
artifacts = []
for suffix in ('bit', 'ltx', 'xsa'):
    p = exp / 'build' / f'{args.basename}.{suffix}'
    if suffix == 'ltx' and not p.exists():
        continue   # the ILA debug core is not in this design, so there is no probe file
    data = p.read_bytes()
    if not data:
        raise ValueError(f'Empty artifact: {p}')
    artifacts.append({'path': str(p.relative_to(root)), 'bytes': len(data),
                      'sha256': hashlib.sha256(data).hexdigest()})
metrics = {'generated_at': datetime.now().astimezone().isoformat(),
           'tool': 'Vivado 2025.2', 'part': 'xck26-sfvc784-2LV-c',
           'stage': 'implemented_and_bitstream_written',
           'scope': args.scope,
           'resources': resources, 'timing': timing,
           'hardware_verified': False, 'hardware_RTT_ns': None,
           'artifacts': artifacts}
(result / 'metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
print(json.dumps(metrics, indent=2))
