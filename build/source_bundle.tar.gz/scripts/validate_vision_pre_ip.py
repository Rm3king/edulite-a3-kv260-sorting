#!/usr/bin/python3
"""Bind the vision_pre HLS inputs, its C/RTL PASS and the generated IP before system builds (as validate_fk_batch_ip.py)."""
from pathlib import Path
import argparse,hashlib,json
r=Path(__file__).resolve().parents[1];p=r/'contest/vision_pre';ap=argparse.ArgumentParser();ap.add_argument('--write',action='store_true');a=ap.parse_args()
manifest=p/'result/ip_validation.json'
if a.write:
 report=p/'build/vision_pre/hls/sim/report/vision_pre_cosim.rpt';text=report.read_text()
 assert 'Pass' in text or 'PASS' in text,text
 files=sorted((p/'source').glob('*'))+sorted((p/'tb').glob('*'))+[p/'hls_config.cfg',p/'model.py',p/'vectors/index.txt']
 assert report.stat().st_mtime>=max(f.stat().st_mtime for f in files),'Cosim predates a source change'
 files+=sorted(f for f in (p/'build/vision_pre/hls/impl/ip').rglob('*') if f.is_file())
 value=dict(status='PASS_CRTL_AND_IP_BOUND',files={str(f.relative_to(r)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files})
 manifest.write_text(json.dumps(value,indent=2)+'\n')
else:value=json.loads(manifest.read_text())
assert value['status']=='PASS_CRTL_AND_IP_BOUND'
for name,digest in value['files'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==digest,name
print('PASS vision_pre IP hashes',len(value['files']))
