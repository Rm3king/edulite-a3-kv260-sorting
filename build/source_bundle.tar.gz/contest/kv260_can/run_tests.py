#!/usr/bin/python3
"""Bounded regressions with immutable per-run logs and explicit PASS markers."""
import argparse,datetime,json,os,subprocess,sys,hashlib
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--simulator',choices=['iverilog','xsim'],default='iverilog');args=ap.parse_args()
root=Path(__file__).resolve().parents[2];exp=root/'contest/kv260_can'
stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
out=exp/'result'/stamp;out.mkdir()
env=os.environ.copy();env['PATH']=str(root/'.tools/bin')+':'+str(root/'.tools/usr/bin')+':'+env['PATH']
env['LD_LIBRARY_PATH']=str(root/'.tools/usr/lib/x86_64-linux-gnu')+':'+env.get('LD_LIBRARY_PATH','')
sources=sorted((root/'third_party/opencores_can').glob('*.v'))+sorted((exp/'rtl').glob('*.sv'))+sorted((exp/'rtl').glob('*.v'))
tracked=sources+sorted((exp/'tb').glob('*.sv'))+sorted((exp/'tb').glob('*.mem'))+[Path(__file__).resolve()]
def hashes():return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in tracked}
initial_hashes=hashes()
results=[]
def run(name,args,timeout=180,cwd=root):
    with (out/(name+'.log')).open('w') as log:
        p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    if p.returncode:raise RuntimeError(f'{name} exited {p.returncode}; see {out}')
    return (out/(name+'.log')).read_text()
try:
    run('vectors',['/usr/bin/python3',exp/'tb/generate_wire_vectors.py'])
    run('wide_vectors',['/usr/bin/python3',exp/'tb/generate_wide_vectors.py'])
    run('mit_vectors',['/usr/bin/python3',exp/'tb/generate_mit_vectors.py','--check'])
    for name in ['tx_timing_monitor','tracking_monitor','rx_buffer','axi_lite_request','tx_rejection','can_engine','wire_receive','trajectory_stream','trajectory_correction','trajectory_wide','csp_stream_can','csp_wide_can','mit_trajectory','mit_stream_can','filtered_damping','mit_damping_can']:
        top='tb_'+name;exe=out/(name+'.vvp')
        if args.simulator=='iverilog':
            run(name+'_compile',['iverilog','-g2012','-DCAN_WISHBONE_IF','-I',root/'third_party/opencores_can','-I',exp/'result','-s',top,'-o',exe,*sources,exp/'tb'/(top+'.sv')])
            log=run(name,['vvp',exe]+(['+SOFT'] if name=='tx_rejection' else []),timeout=900)
        else:
            if not (out/'contest').exists():(out/'contest').symlink_to(root/'contest',target_is_directory=True)
            run(name+'_compile',['xvlog','--sv','--define','CAN_WISHBONE_IF','-i',root/'third_party/opencores_can','-i',exp/'result',*sources,exp/'tb'/(top+'.sv')],cwd=out)
            run(name+'_elaborate',['xelab',top,'-s',top,'-mt','4','-debug','typical'],cwd=out)
            log=run(name,['xsim',top,'-runall']+(['-testplusarg','SOFT'] if name=='tx_rejection' else []),timeout=900,cwd=out)
        markers=[x for x in log.splitlines() if x.startswith('TEST_PASS')]
        if not markers or any(x in log for x in ['FATAL:','Fatal:','ERROR:']):raise RuntimeError(f'{name}: no clean functional PASS')
        results.append({'test':name,'status':'PASS','evidence':markers})
        print(markers[-1],flush=True)
    if hashes()!=initial_hashes:raise RuntimeError('Sources changed during regression; results are not a release gate')
    status='PASS'
except Exception as exc:
    status='FAIL';results.append({'error':str(exc)});print(exc,file=sys.stderr)
report={'status':status,'tests':results,'physical_can':'NOT_RUN','simulator':args.simulator,'sources':initial_hashes}
(out/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
(exp/'result/latest_validation.json').write_text(json.dumps({'report':str((out/'validation.json').relative_to(root)),**report},indent=2)+'\n')
print('Evidence:',out)
sys.exit(status!='PASS')
